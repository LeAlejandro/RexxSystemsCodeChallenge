
-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- Crear la base de datos "bookstore"
CREATE DATABASE IF NOT EXISTS bookstore;
USE bookstore;

CREATE TABLE products (
  product_id INT PRIMARY KEY,
  product_name VARCHAR(255) NOT NULL
);

CREATE TABLE sales (
  sale_id INT PRIMARY KEY,
  customer_name VARCHAR(255) NOT NULL,
  customer_mail VARCHAR(255) NOT NULL,
  product_id INT,
  sale_date DATETIME NOT NULL,
  product_price DECIMAL(10, 2) NOT NULL,
  FOREIGN KEY (product_id) REFERENCES products(product_id)
);

