<?php
//phpinfo();
// DataBase connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookstore";

// Check Connection
try {
   $conn = mysqli_connect($servername, $username, $password, $dbname); 
} catch (mysqli_sql_exception $e) {
    echo $e->getMessage();
}

// Read JSON File
$jsonData = file_get_contents('../json/archivojson.json');
    //echo '<pre>';print_r($jsonData);
// Decode JSON
$data = json_decode($jsonData, true);
    //echo '<pre>';var_dump($data);

// Insert in Database
foreach ($data as $item) {
    $productId = mysqli_real_escape_string($conn, $item['product_id']);
    $productName = mysqli_real_escape_string($conn, $item['product_name']);    
    $saleId = $conn->real_escape_string($item['sale_id']);
    $customerName = $conn->real_escape_string($item['customer_name']);
    $customerMail = $conn->real_escape_string($item['customer_mail']);
    $productPrice = $conn->real_escape_string($item['product_price']);
    $saleDate = $conn->real_escape_string($item['sale_date']);
    
    // Check if product_id already exist in products
    $checkProductQuery = "SELECT * FROM products WHERE product_id = '$productId'";
        //echo '<pre>';print_r($checkProductQuery);
    $result = $conn->query($checkProductQuery);
        //echo '<pre>';print_r($result);
    // Insert in products
    if ($result->num_rows == 0) {
        echo '<pre>';print_r("Product not exist, insert in DataBase");
        $insertProductQuery = "INSERT INTO products (product_id, product_name) VALUES ('$productId' ,'$productName')";
        $conn->query($insertProductQuery);
    } else {
    echo '<pre>';print_r("Product already exists in DataBase");
    }
    // Check if sale_id already exist in sales
    $checkProductQuery = "SELECT * FROM sales WHERE sale_id = '$saleId'";
        //echo '<pre>';print_r($checkProductQuery);
    $result = $conn->query($checkProductQuery);
        //echo '<pre>';print_r($result);
    // Insert in sales
    if ($result->num_rows == 0) {
        echo '<pre>';print_r("Sale not exist, insert in DataBase");
        $insertSaleQuery = "INSERT INTO sales (sale_id, customer_name, customer_mail, product_id, sale_date, product_price)
                        VALUES ('$saleId','$customerName', '$customerMail', '$productId', '$saleDate', '$productPrice')";
        //echo '<pre>';print_r($insertSaleQuery);
        $conn->query($insertSaleQuery);    
    } else {
        echo '<pre>';print_r("Sale already exists in DataBase");
    }
}
// Close conection
$conn->close();
?>



