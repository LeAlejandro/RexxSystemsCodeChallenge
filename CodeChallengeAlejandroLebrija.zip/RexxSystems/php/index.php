<?php
//session_start();

// DataBase conecction
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookstore";

// Check connection
try {
   $conn = mysqli_connect($servername, $username, $password, $dbname); 
} catch (mysqli_sql_exception $e) {
    echo $e->getMessage();
}

// Filter results
$filterCustomer = $_POST['customer'] ?? '';
$filterProduct = $_POST['product'] ?? '';
$filterPrice = $_POST['price'] ?? '';

// Build SQL with Filters
$sql = "SELECT sales.*, products.product_name
        FROM sales
        INNER JOIN products ON sales.product_id = products.product_id
        WHERE customer_name LIKE '%$filterCustomer%'
        AND products.product_name LIKE '%$filterProduct%'
        AND product_price LIKE '%$filterPrice%'";
$result = $conn->query($sql);
//echo '<pre>';print_r($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookstore</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- Formats & Filters -->
<h2>Choose a filter</h2>
<form action="index.php" method="post">
    <label for="customer">Customer:</label>
    <input type="text" name="customer" placeholder="Customer" value="<?php echo $filterCustomer; ?>">

    <label for="product">Product:</label>
    <input type="text" name="product" placeholder="Product" value="<?php echo $filterProduct; ?>">

    <label for="price">Price:</label>
    <input type="number" name="price" placeholder="Price" step="0.01" value="<?php echo $filterPrice; ?>">
    <br><br>
    <button type="submit">Apply Filter</button>
</form>

<?php
// Show Table Results
if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>Customer</th><th>Email</th><th>Product</th><th>Price</th><th>Sale Date</th></tr>";

    $totalPrice = 0;

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['customer_name']}</td>";
        echo "<td>{$row['customer_mail']}</td>";
        echo "<td>{$row['product_name']}</td>";
        echo "<td>{$row['product_price']}</td>";
        echo "<td>{$row['sale_date']}</td>";
        echo "</tr>";
        $totalPrice += floatval($row['product_price']);
    }
    // Show last row with price
    echo "<tr><td colspan='4'><strong>Total Price:</strong></td><td><strong>{$totalPrice}</strong></td></tr>";
    echo "</table>";
} else {
    echo "Not available data.";
}
// Close conection
$conn->close();
?>
</body>
</html>
